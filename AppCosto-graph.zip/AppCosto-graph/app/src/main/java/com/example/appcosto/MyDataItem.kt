package com.example.appcosto


class MyDataItem (

    val id : Int,
    val title : String,
    val description : String
)