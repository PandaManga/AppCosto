package com.example.appcosto

class MyData {
}